import boto3
import json
from botocore.vendored import requests

def lambda_handler(event, context):
  
    # initialize variables
    output = ''
    param = ''
    s3 = boto3.client('s3')

    # find parameter in event variable
    # if it comes from function_url with POST method
    if 'body' in event:
      body = dict(item.split('=') for item in event['body'].split(', '))
      if 'param' in body:
        param = body['param']
    # if it comes from aws
    elif 'param' in event:
      param = event['param']
      
    # read terraform state file for outputs
    original = s3.get_object(
      Bucket='demicon-s3',
      Key='terraform.tfstate')
    data = json.load(original['Body'])
    
    # get all or specific output
    if param != '':
      if param in data['outputs']:
        output = data['outputs'][param]['value']
    else:
      output = data['outputs']
      
    return {
        'statusCode': 200,
       'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps(output)
    }
